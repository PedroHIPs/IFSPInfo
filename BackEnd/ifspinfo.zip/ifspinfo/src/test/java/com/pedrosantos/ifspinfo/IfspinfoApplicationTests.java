package com.pedrosantos.ifspinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IfspinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
